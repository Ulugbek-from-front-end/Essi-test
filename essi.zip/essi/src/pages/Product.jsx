import React from 'react'
import Header from '../components/Header/Header'
import Header from '../components/Product_page/Product_page'


const Product = () => {
  return (
    <>
    <Header />
    <Product_page />
    </>
  )
}

export default Product