import React from 'react'
import Error from '../components/Error/Error'

const Error404 = () => {
  return (
    <>
      <Error/>
    </>
  )
}

export default Error404