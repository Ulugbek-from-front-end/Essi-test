import React, { useState } from 'react';
import "./Product_page.scss";
import { useParams } from 'react-router-dom';
import Minicardboard from '../components/minicardboard/minicardboard';
import productsData from "./products.json"

const Id_two = () => {
  const [hover, setHover] = useState(false);
  const handleHover = () => {
    setHover(!hover);
  };

  const [products, setProducts] = useState(productsData);

  // берём продукт по id (в данном случае 2)
  const product = products.find((p) => p.id === 2);

  return (
    <>
      <div className="container4">
        <div className="flex_wrapper">
          <div className="total_new_card">
            {product && (
              <div className="new_card" key={product.id}>
                <img
                  src={product.img}
                  alt={product.title}
                  className="total_new_card__img"
                />
                <h1 className="total_new_card__h1">{product.title}</h1>
                <p className="total_new_card__description">{product.description}</p>
                <button
                  className="btn4"
                  onMouseEnter={handleHover}
                  onMouseLeave={handleHover}
                  style={{ backgroundColor: hover ? "rgb(252, 73, 73)" : "white" }}
                >
                  <a href="/" className="a1">Вернуться на лобби</a>
                </button>
              </div>
            )}
          </div>
        </div>
      </div>

      <div className="recommendation-section">
        {/* передаем id продукта, который показывается, чтобы скрыть его в списке */}
        <Minicardboard excludeId={2} />
      </div>
    </>
  );
};

export default Id_two;
