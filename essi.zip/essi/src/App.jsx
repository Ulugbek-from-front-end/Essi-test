import { Fragment, useState } from "react";
import "./App.scss";
import Header from "./components/Header/Header";
import Product from "./pages/Product/Product";
import { BrowserRouter } from "react-router-dom";
import Cardboard from "./components/Cardboard/Cardboard";
import Product_page from "./pages/Product_page/Product_page";

const App = () => {
  return (
    <Fragment>
      <Header />
      <Product />
      <Cardboard />
      {/* <Product_page/> */}
    </Fragment>
  );
};

export default App;
