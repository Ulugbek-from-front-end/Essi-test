import { Fragment, useState } from 'react'
import './App.scss'
import Header from './components/Header/Header'
import Product from './pages/Product/Product'
import { BrowserRouter } from 'react-router-dom'
import Cardboard from './components/Cardboard/Cardboard'


const  App=() =>{

  return (
    
    <Fragment>
      <Cardboard/>
       {/* <Header/> */}
      {/* <Product/>  */}
    </Fragment>
  )
}

export default App
