import React, { useState, useEffect } from 'react';
import "./minicardboard.scss"
import { Link } from 'react-router-dom';
import productsData from "../../pages/products.json"

const   minicardboard = () => {
  const [products, setProducts] = useState(productsData);
  const redirectToWebsite = (id) => {
    window.location.href = `http://localhost:5173/${id}`; 
};

  return (
    <>
    <div className="container3">
     
        <div className="container3__wrapper">
        <div className="  cards">
          {products.length > 0 ? (  
            products.slice(0,5).map((product) => 
              <Link to={"/product/" + product.id} >
              <div className="card" key={product.id}>
                <img src={product.img} alt={product.title} className="card__img" />
                <h1 className="card__h1">{product.title}</h1>
                <h2 className="card__h2_2">Тип Продукта</h2>
                <h2 className="card__h2">{product.tag}</h2>
                
              </div>
              </Link >
        )
      ) : (
        <div className="loading-indicator">
          <div className="loading-line"></div>
        </div>
      )}
          </div>
        </div>  
      </div>
      </>
  );
};

export default minicardboard;
