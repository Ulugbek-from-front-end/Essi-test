import React, { useState, useEffect } from 'react';
import "./Cardboard.scss"
const Cardboard = () => {
  const [products, setProducts] = useState([]);

  
  const fetchData = async () => {
    try {
      const response = await fetch('DB.json',{
        method: "get"
      });
      if (!response.ok) { 
        throw new Error('Network response was not ok');
      }


      
      
      const jsonData = await response.json();
      setProducts(jsonData.products.slice(0, 4)); // Берём только первые 4 элемента из массива products
    } catch (error) {
      // console.error('Error fetching data:', error);
    }
  };
  useEffect(() => {
    fetchData();
    
  }, []);
  console.log(fetchData);


  return (
    <>
      <div className="container">a
        {products.map((products) => (
          <div className="card" key={products.id} >
            <img src={products.img} alt={products.title} className="card__img" />
            <h1 className="card__h1" > {products.title}</h1>
            <p>{products.description}</p>
          </div>
        ))}
      
      </div>
    </>
  );
};

export default Cardboard;
