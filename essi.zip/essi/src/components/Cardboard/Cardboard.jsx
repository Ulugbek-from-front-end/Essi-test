import React, { useState, useEffect } from 'react';
import "./Cardboard.scss"

const Cardboard = () => {
  const [products, setProducts] = useState([
    {
      id: "1",
      img: "./клубника_4.png",
      title: "Йогурт Клубника - 2.5%",
      description: "Пищевая и энергетическая ценность в 100 г продукта Жир-1,5 г, Белок-2,85 г, Углеводы-12,8 г Энергетическая ценность-76 ккал / 321 кДж «Клубника»  Йогурт полужирный 2,5% с изысканным вкусом клубники – это погружение в мир нормализованного коровьего молока, сладкого сахара и сочной клубничной нежности, создающее в каждой порции яркое воспоминание о летнем утре с первыми лучами солнца и свежими ягодами, окутанными нежным ароматом. Состав: молоко коровье нормализованное, сахар, наполнитель клубника (сахар, клубника, вода, загуститель: модифицированный крахмал, регуляторы кислотности: цитрат натрия, лимонная кислота, красители: антоцианы, экстракт паприки, ароматизаторы: «Крем», «Клубника»), сухое обезжиренное молоко, закваска."
    },
    {
      id: "2",
      img: "./banan_kivi_3.png",
      title: "Йогурт Банан-Киви - 2.5%",
      description: "Описание продукта 2"
    },
    {
      id: "3",
      img: "./ananas_3.png",
      title: "Йогурт Ананас-Апельсин - 2.5%",
      description: "Описание продукта 3"
    },
    {
      id: "4",
      img: "./mango_2.png",
      title: "Йогурт Персик-Манго - 2.5%",
      description: "Описание продукта 4"
    }
  ]);

  return (
    <div className="container3">
      <div className="container">
        <div className="container3__wrapper">
        <div className="cards">
          {products.length > 0 ? (  
            products.map((product) => 
              <div className="card" key={product.id}>
                <img src={product.img} alt={product.title} className="card__img" />
                <h1 className="card__h1">{product.title}</h1>
                
              </div>
        )
      ) : (
        <div className="loading-indicator">
          <div className="loading-line"></div>
        </div>
      )}
          </div>
        </div>  
      </div>
    </div>
  );
};

export default Cardboard;
